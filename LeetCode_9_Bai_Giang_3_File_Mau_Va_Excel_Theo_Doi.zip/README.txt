BỘ NOTEBOOK LEETCODE ĐÃ TẠO TRONG CUỘC TRÒ CHUYỆN

01_DSA_Python/: 5 notebook mới (Easy vị trí 36, 37, 38, 39, 44 theo chỉ mục cũ)
02_SQL_Database/: 4 notebook mới (Easy vị trí 40, 41, 42, 43 theo chỉ mục cũ)
03_File_mau_do_nguoi_dung_cung_cap/: 3 notebook mẫu gốc (Two Sum, Palindrome Number, Roman to Integer).
04_Bang_theo_doi/: Excel theo dõi tiến độ tạo giáo trình 3.711 bài DSA Python.

Tổng: 9 notebook do trợ lý biên soạn trong chat + 3 notebook mẫu do người dùng cung cấp.
Cột 'Easy vị trí' là thứ tự trước khi lọc các bài không phải DSA.

Mở .ipynb bằng Jupyter Notebook / JupyterLab / Google Colab.
Các bài SQL có ví dụ SQLite chạy từ Python và câu lệnh SQL dùng để nộp LeetCode.
