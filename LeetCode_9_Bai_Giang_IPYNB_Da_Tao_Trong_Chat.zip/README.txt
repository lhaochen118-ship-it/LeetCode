LEETCODE — 9 BÀI GIẢNG IPYNB ĐƯỢC TẠO TRONG CUỘC TRÒ CHUYỆN NÀY

Các notebook này được biên soạn theo hướng dẫn phong cách dạy Python từ căn bản.

THƯ MỤC 01_DSA_Python: 5 bài (LeetCode #168, #169, #170, #171, #190).
THƯ MỤC 02_SQL_Database: 4 bài (LeetCode #175, #181, #182, #183).

Các vị trí Easy 36–44 là vị trí trong danh mục gốc, không phải ID LeetCode.

Lưu ý: Ba notebook Two Sum (#1), Palindrome Number (#9), Roman to Integer (#13) là FILE MẪU do người dùng cung cấp ban đầu nên không được tính trong 9 bài biên soạn mới.

Mở file bằng Jupyter Notebook hoặc Google Colab. Bài SQL có phần chạy mô phỏng bằng sqlite3 ngay trong Python.

DANH SÁCH NOTEBOOK:
- 01_DSA_Python/easy_036_leetcode_0168_excel_sheet_column_title_vi.ipynb | LeetCode #168 | 70 cells
- 01_DSA_Python/easy_037_leetcode_0169_majority_element_vi.ipynb | LeetCode #169 | 76 cells
- 01_DSA_Python/easy_038_leetcode_0170_two_sum_iii_data_structure_design_vi.ipynb | LeetCode #170 | 90 cells
- 01_DSA_Python/easy_039_leetcode_0171_excel_sheet_column_number_vi.ipynb | LeetCode #171 | 72 cells
- 02_SQL_Database/easy_040_leetcode_0175_combine_two_tables_sql_vi.ipynb | LeetCode #175 | 77 cells
- 02_SQL_Database/easy_041_leetcode_0181_employees_earning_more_than_their_managers_sql_vi.ipynb | LeetCode #181 | 90 cells
- 02_SQL_Database/easy_042_leetcode_0182_duplicate_emails_sql_vi.ipynb | LeetCode #182 | 84 cells
- 02_SQL_Database/easy_043_leetcode_0183_customers_who_never_order_sql_vi.ipynb | LeetCode #183 | 98 cells
- 01_DSA_Python/easy_044_leetcode_0190_reverse_bits_vi.ipynb | LeetCode #190 | 104 cells